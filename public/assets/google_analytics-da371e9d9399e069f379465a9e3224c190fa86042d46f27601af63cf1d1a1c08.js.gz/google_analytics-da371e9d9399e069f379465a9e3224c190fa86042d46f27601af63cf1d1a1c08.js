(function() {
  jQuery(function() {
    return $(document).on('page:change', function() {
      if (window.ga != null) {
        ga('set', 'location', location.href.split('#')[0]);
        return ga('send', 'pageview', {
          "title": document.title
        });
      }
    });
  });

}).call(this);
